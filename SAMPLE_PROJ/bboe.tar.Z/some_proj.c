#include <stdio.h>

int main() {
  printf("Some Project!\n");
}
